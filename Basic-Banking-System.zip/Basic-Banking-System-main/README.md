# Basic-Banking-System
**SPARKSBANK**

The Sparks Foundation Internship Project:Basic Banking System
This Web application is used to transfer money between multiple users virtually and also helps to see the transaction details.
This project consist of 10 dummy users.

**TECHNOLOGY STACK:**

--> Front-end : HTML, CSS, Bootstrap & Javascript

--> Back-end : PHP 

-->Database : MySQL

**FLOW OF THE PROJECT:**

Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.


**HOSTING PALTFORM** 
--> 000Webhost

Website Link:https://incrust-jam.000webhostapp.com/



Contact:https://www.linkedin.com/in/dhaarini-murugesh-b8a179199
         
 

